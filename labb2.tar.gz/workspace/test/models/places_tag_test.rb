require 'test_helper'

class PlacesTagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
