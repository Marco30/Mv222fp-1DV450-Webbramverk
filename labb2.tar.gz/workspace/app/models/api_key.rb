class ApiKey < ActiveRecord::Base
end
