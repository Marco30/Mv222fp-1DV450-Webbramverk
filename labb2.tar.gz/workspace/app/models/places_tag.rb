class PlacesTag < ActiveRecord::Base
end
